

<?php $__env->startSection('title', 'Login'); ?>
<?php echo $__env->make('adminlte::auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reportdatpaq\resources\views/auth/login.blade.php ENDPATH**/ ?>