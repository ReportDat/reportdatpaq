

<?php $__env->startSection('title', 'Register'); ?>
<?php echo $__env->make('adminlte::auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reportdatpaq\resources\views/auth/register.blade.php ENDPATH**/ ?>