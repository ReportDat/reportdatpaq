

<?php $__env->startSection('title', 'Reports'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de reportes</h1>
    <div class="row">
        <div class="col-sm-12 text-right">
            <a class="btn btn-primary" href="<?php echo e(route("report.create")); ?>"><i class="fas fa-plus"></i> Crear reporte</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table id="table_id" class="table table-bordered display" style="width:100%">
    <thead>
        <tr>
            <th>Fecha factura</th>
            <th>Tienda</th>
            <th>Número de documento</th>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Guía</th>
            <th>Transportadora</th>
            <th>Ciudad</th>
            <th>Dirección</th>
            <th>Valor deuda</th>
            <th>Producto</th>
            <th>Valor compra</th>
            <th>Motivo</th>
            <td>Acciones</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($report->date_purchase); ?></td>
                <td><?php echo e($report->store); ?></td>
                <td><?php echo e($report->document_number); ?></td>
                <td><?php echo e($report->name); ?></td>
                <td><?php echo e($report->phone); ?></td>
                <td><?php echo e($report->guide_number); ?></td>
                <td><?php echo e($report->conveyor); ?></td>
                <td><?php echo e($report->city); ?></td>
                <td><?php echo e($report->address); ?></td>
                <td><?php echo e($report->debt_value); ?></td>
                <td><?php echo e($report->product); ?></td>
                <td><?php echo e($report->shipping_value); ?></td>
                <td><?php echo e($report->reason); ?></td>
                <td class="text-center">
                    <div class="dropdown">
                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                          Acción
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <form action="<?php echo e(route("report.update", $report)); ?>" method="post">  
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <?php if($report->is_trustworthy == true): ?>
                                    <input type="hidden" name="is_trustworthy" value="0">
                                    <button class="dropdown-item" href="#">Cambiar a no confiable</button>
                                <?php else: ?>
                                    <input type="hidden" name="is_trustworthy" value="1">
                                    <button type="submit" class="dropdown-item" href="#">Cambiar a confiable</button>
                                <?php endif; ?>
                            </form>  
                        </div>
                    </div>
                </td>
            </tr>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th>Fecha factura</th>
            <th>Tienda</th>
            <th>Número de documento</th>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Guía</th>
            <th>Transportadora</th>
            <th>Ciudad</th>
            <th>Dirección</th>
            <th>Valor deuda</th>
            <th>Producto</th>
            <th>Valor compra</th>
            <th>Motivo</th>
            <th>Acciones</th>
        </tr>
    </tfoot>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready( function () {
            $('#table_id').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reportdatpaq\resources\views/report/index.blade.php ENDPATH**/ ?>