@extends('adminlte::auth.register')

@section('title', 'Register')